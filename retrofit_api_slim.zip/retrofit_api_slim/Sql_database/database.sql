-- created by belal
-- website www.simplifiedcoding.net
-- Table: users
CREATE TABLE users (
    id int NOT NULL AUTO_INCREMENT,
    email varchar(200) NOT NULL,
    password varchar(200) NOT NULL,
    name varchar(200) NOT NULL,
    school varchar(255) NOT NULL,
    CONSTRAINT users_pk PRIMARY KEY (id)
);
-- End of file.